
/**
 * Format the publication titles in the publication title input field.
 * If a title has pmid appending to it (this title comes from the
 * publication selection popup window), take the pmid and delete the
 * title; finally format the string in the publication title input ]
 * box to the format of PQ II publication query string and set the
 * fomatted string back to the publication title input field
 * @param formName -- the name of the form where the publication title input
 * field is at.
 * @param pubTitleFieldname -- The name of the publication input field
 */
function formatPublicationTitles(pubFormName, pubTitleFieldName, putTitleHiddenFieldName, pubPmidHiddenFieldName) {
	var pubField = eval("document." + pubFormName + "." + pubTitleFieldName);
	var pubTitleHiddenField = eval("document." + pubFormName + "." + putTitleHiddenFieldName);
	var pubPmidHiddenField = eval("document." + pubFormName + "." + pubPmidHiddenFieldName);
	if (!pubField) {
		return;
	}
	var pubTitleStr = pubTitleHiddenField.value;
	var pubPmidStr = pubPmidHiddenField.value;
	var pubValue = pubField.value;

	(!pubTitleStr)?pubTitleStr="":pubTitleStr=trim(pubTitleStr);
	(!pubPmidStr)?pubPmidStr="":pubPmidStr=trim(pubPmidStr);
	(!pubValue)?pubValue="":pubValue=trim(pubValue);

	pubValue = trim(pubValue);
	orReg = /OR/i;
	if (pubValue == "") {
		return;
	} else if ( (pubValue.length == 2) && (orReg.test(pubValue)) ) {
		// if pubValue is single "or", treat it as real title keyword
		pubTitleHiddenField.value = pubValue;
		return;
	}

	var formatPubTitleStr = formatPubTitles(pubValue);
	if ( (pubTitleStr != "") && (formatPubTitleStr != "") ) {
		pubTitleStr = pubTitleStr + " OR " + formatPubTitleStr;
	} else {
		pubTitleStr = pubTitleStr + formatPubTitleStr;
	}

	pubTitleHiddenField.value = pubTitleStr;

	var formatPubPmidStr = formatPubPMIDs(pubValue);
	if ( (pubPmidStr != "") && (formatPubPmidStr != "") ) {
		pubPmidStr = pubPmidStr + " OR " + formatPubPmidStr;
	} else {
		pubPmidStr = pubPmidStr + formatPubPmidStr;
	}

	pubPmidHiddenField.value = pubPmidStr;
}

/**
 * Extract all the pmid from the pubTitleStr. If multiple pmids in the
 * pubTitleStr, concatnate them togather using " OR " as separator
 * @param pubTitleStr -- the value in publication title input box
 * @return extracted and concatnate pmid string
 */
function formatPubPMIDs(pubTitleFieldValue) {
	titlePmidReg = /\[[^\[\]]+\]/ig;
	pmidReg = /PMID:\s*(\d+)/i;

	var pmid;
	var titlePmidArr = pubTitleFieldValue.match(titlePmidReg);

	if ( (titlePmidArr == null) || (!titlePmidArr) ){
		return "";
	}

	var pmid;
	var pmidStr = "";
	for (var i=0; i<titlePmidArr.length; i++) {
		pmid = pmidReg.exec(titlePmidArr[i])[1];
		if (pmidStr != "") {
			pmidStr = pmidStr + " OR " + pmid;
		} else {
			pmidStr = pmid;
		}
	}

	return pmidStr;
}

/**
 * Extract all the publication titles (without pmid bondled with it)
 * from the pubTitleStr. If multiple publication titles in the
 * pubTitleStr, concatnate them togather using " OR " as separator
 * @param pubTitleStr -- the value in publication title input box
 * @return extracted and concatnate publication title string
 */
function formatPubTitles(pubTitleFieldValue) {
	titlePmidReg = /\[[^\[\]]+\]/ig;
	orReg = /\sOR\s/ig;

	var tempPubStr = pubTitleFieldValue.replace(titlePmidReg, "");
	if ( (!tempPubStr) || (tempPubStr.length == 0) ) {
		return "";
	}
	
	var pubTitleArr = tempPubStr.split(orReg);

	if ((pubTitleArr == null) ||(!pubTitleArr)) {
		return "";
	}

	var pubTitleStr = "";
	var putTitle;
	for (var i=0; i< pubTitleArr.length; i++) {
		pubTitle = trim(pubTitleArr[i]);
		if (pubTitle != "") {
			if (pubTitleStr != "") {
				pubTitleStr = pubTitleStr + " OR " + pubTitle;
			} else {
				pubTitleStr = pubTitle;
			}
		}
	}

	return pubTitleStr;
}