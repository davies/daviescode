
var HELP_LAYER = "dynHelp";
var szCurHelp;

firstTime = 1;
firstMsg = "";
function doHelp(szId, bOn)
{
//  alert("hello");
  //alert("doHelp: " + szId + "," + bOn);
//  var szTmp = eval(szId + "Desc");
  var szTmp = "";

  if (bOn)
    szTmp = szId;  
    //eval(szId + "Desc");  This line is no longer needed since we're not passing a variable name, but rather the text itself
  else
    szTmp = firstMsg;
  //alert("szTmp :"+ szTmp);
  if (BR_NS4)
    document.dynHelp.top = document.tipBorder.pageY + 18;

  // ie?  dynHelp.style.top = tipBorder.offsetTop + 18;  
  //var szFunc ="writeLayer(HELP_LAYER,'"+szTmp+"')";
  //var nLocDelay = 0;
  if (firstTime == 1) {
    firstTime = 0;
    firstMsg = szTmp;
  } 
  //setTimeout(szFunc, nLocDelay);

if(BR_Mac)
	szTmp="<nobr>" + szTmp + "</nobr>";
  writeLayer(HELP_LAYER, szTmp);
}



//  Following are strings for various hot help components.  Should be broken into generic
//  and page specific files to optimize load times....


//  They used to live here, but now the actual strings live in the message files (part of the new local language support)
