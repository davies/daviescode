var fbNumBars = 16;	// number of bars in the wave
var arrColors = [[255, 195], [153, 220], [0, 121]];	// the possible colors of the bars
var arrBarColors = [0];	// the actual colors for each bar
var arrBars = [0];		// the bars
var arrPercents = [0];	// the hight of the bars
var fbWidth = 2;		// the width of each bar
var fbGap = 1;			// the space between bars
var fbHeight = 24;		// the max height of each bar
var fbInitLeft = 200;	// left will be overridden to left of search button
var fbInitTop = 200;	// top will be overridden to top of search button
var iTimeOutInterval = 20;	// the bigger the number the slower the wave

function searchFeedback()
{
	if (document.layers || arrBars[0])
		return;

	var elementReference = document.getElementById("whereIsButton");
	if (elementReference == null)
		return;

/*	arrColors[0][0] = Math.floor(Math.random()*30)+225;
	arrColors[0][1] = Math.floor(Math.random()*40)+190;
	arrColors[1][0] = Math.floor(Math.random()*40)+148;
	arrColors[1][1] = Math.floor(Math.random()*40)+215;
	arrColors[2][0] = Math.floor(Math.random()*40);
	arrColors[2][1] = Math.floor(Math.random()*40)+161;
*/
// find the location of the search button
	fbInitLeft = DL_GetElementLeft(elementReference);
	fbInitTop = DL_GetElementTop(elementReference);	// show the wave under the button

	var sRed, sGreen, sBlue;
	var incRed, incGreen, incBlue;
	var fSin;
	incRed = Math.floor((arrColors[0][1] - arrColors[0][0]));
	incGreen = Math.floor((arrColors[1][1] - arrColors[1][0]));
	incBlue = Math.floor((arrColors[2][1] - arrColors[2][0]));

	for (i=0; i<fbNumBars; i++)
	{
		fSin2 = Math.sin(i*Math.PI/(fbNumBars-1));
		sRed = fb_getColor(0, Math.abs(fSin2)*incRed);
		sGreen = fb_getColor(1, Math.abs(fSin2)*incGreen);
		sBlue = fb_getColor(2, Math.abs(fSin2)*incBlue);
		arrBars[i] = document.createElement("DIV");
		document.body.appendChild(arrBars[i]);
		arrBars[i].innerHTML = "&nbsp;";
		with (arrBars[i].style)
		{
			position = "absolute";
			fontSize = fbWidth+"px";
			lineHeight = fbWidth+"px";
			background = "#FF9900";
			zIndex = "20";
			width = fbWidth+"px";
			height = "2px";
			left = (i*(fbWidth + fbGap)+fbInitLeft)+"px";
			top = (fbHeight/2 - 1+fbInitTop)+"px";
		}
		arrBars[i].maxheight = fbHeight * fSin2;
		arrPercents[i] = 0;
		arrPercents[i+fbNumBars] = fSin2;
		arrBarColors[i] = "#FF9900";
		arrBarColors[i+fbNumBars] = "#"+sRed+sGreen+sBlue;
	}
	fbWaveLoop();
}

var fb_loopdir = 1;
var fb_loopcount = 0;
function fbWaveLoop()
{
	for (i=1; i<fbNumBars-1; i++)
	{
		arrBars[i].style.height = (2 + arrPercents[i]*arrBars[i].maxheight) + "px";
		arrBars[i].style.top = (fbHeight/2 - (2 + arrPercents[i]*arrBars[i].maxheight)/2 + fbInitTop) + "px";
		arrBars[i].style.background = arrBarColors[i];
	}

	var fPct0;
	var sColor0;
	if (fb_loopdir == 1)
	{
		var fPct0 = arrPercents[arrPercents.length-1];
		var sColor0 = arrBarColors[arrPercents.length-1];
		for (i=arrPercents.length-1; i>0; i--)
		{
			arrPercents[i] = arrPercents[i-1];
			arrBarColors[i] = arrBarColors[i-1];
		}
		arrPercents[0] = fPct0;
		arrBarColors[0] = sColor0;
		
/*		if (++fb_loopcount >=  fbNumBars*2)
		{
			fb_loopcount = 0;
			fb_loopdir = -1;
		}
*/		
	}
	else
	{
		var fPct0 = arrPercents[0];
		var sColor0 = arrBarColors[0];
		for (i=0; i<arrPercents.length-1; i++)
		{
			arrPercents[i] = arrPercents[i+1];
			arrBarColors[i] = arrBarColors[i+1];
		}
		arrPercents[arrPercents.length-1] = fPct0;
		arrBarColors[arrPercents.length-1] = sColor0;
		
		if (++fb_loopcount >=  fbNumBars*2)
		{
			fb_loopcount = 0;
			fb_loopdir = 1;
		}
	}
	window.setTimeout("fbWaveLoop()", iTimeOutInterval);
}

function fb_getColor(iColor, iinc)
{
	var sColor = Math.floor((arrColors[iColor][0] + Math.floor(iinc)));
	sColor = returnBase(sColor, 16) + "";
	if (sColor.length < 2)
		sColor = "0" + sColor;
	return sColor;
}


function makeArray() {
    for (i = 0; i<makeArray.arguments.length; i++)
        this[i] = makeArray.arguments[i];
}

// the following was found in a FAQ about converting numbers to HEX in javascript at
// http://www.freeflights.net/atasi/divers/cjvscr/faqqa/fnumber.html
var convert = new makeArray('0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z');
function returnBase(number,base) {
    if (number < base) var output = convert[number];
    else {
        var MSD = '' + Math.floor(number / base);
        var LSD = number - MSD*base;
        if (MSD >= base) var output = returnBase(MSD,base) + convert[LSD];
        else var output = convert[MSD] + convert[LSD];
    }
    return output;
}


// the following scripts were found on 
// http://www.webreference.com/dhtml/diner/realpos4/
function DL_GetElementLeft(eElement)
{
   if (!eElement && this)                    
   {                                         
      eElement = this;                       
   }                                         

   var DL_bIE = document.all ? true : false; 

   var nLeftPos = eElement.offsetLeft;       
   var eParElement = eElement.offsetParent;  

   while (eParElement != null)
   {                                         

      if(DL_bIE)                             
      {
         if( (eParElement.tagName != "TABLE") && (eParElement.tagName != "BODY") )
         {                                   
            nLeftPos += eParElement.clientLeft; 
         }
      }
      else                                   
      {
         if(eParElement.tagName == "TABLE")  
         {                                   
            var nParBorder = parseInt(eParElement.border);
            if(isNaN(nParBorder))            
            {                                
               var nParFrame = eParElement.getAttribute('frame');
               if(nParFrame != null)         
               {
                  nLeftPos += 1;             
               }
            }
            else if(nParBorder > 0)          
            {
               nLeftPos += nParBorder;       
            }
         }
      }
      nLeftPos += eParElement.offsetLeft;    
      eParElement = eParElement.offsetParent; 
   }                                         
   return nLeftPos;                          
}

function DL_GetElementTop(eElement)
{
   if (!eElement && this)                    
   {                                         
      eElement = this;                       
   }                                         

   var DL_bIE = document.all ? true : false; 

   var nTopPos = eElement.offsetTop;         
   var eParElement = eElement.offsetParent;  

   while (eParElement != null)
   {                                         
      if(DL_bIE)                             
      {
         if( (eParElement.tagName != "TABLE") && (eParElement.tagName != "BODY") )
         {                                   
            nTopPos += eParElement.clientTop; 
         }
      }
      else                                   
      {
         if(eParElement.tagName == "TABLE")  
         {                                   
            var nParBorder = parseInt(eParElement.border);
            if(isNaN(nParBorder))            
            {                                
               var nParFrame = eParElement.getAttribute('frame');
               if(nParFrame != null)         
               {
                  nTopPos += 1;              
               }
            }
            else if(nParBorder > 0)          
            {
               nTopPos += nParBorder;        
            }
         }
      }

      nTopPos += eParElement.offsetTop;      
      eParElement = eParElement.offsetParent; 
   }                                         
   return nTopPos;                           
}

