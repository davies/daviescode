// Switch display pages at a given location.

var visiblePages = new Object();

function switchPages(group, page) {
  // Group is a string that identifies the page location where a page is to appear (e.g. "topicTOP"
  // for Suggest Terms or "BOTTOM" for Refine Terms. Only one page at a time can appear per group.
  // Page is a string that identifies the actual page to be displayed. For Suggest Terms, it
  // matches the starting index for the list being displayed (e. g. "8"). For Refine Terms, it
  // includes the term type as well (e. g., "pub0").

  // This method looks for the element with the name <group><page> and makes it visible. It
  // makes invisible whatever page was currently visible in that group. The variable
  // visiblePages acts as a Map, storing one item for each group this method is fed.

  // NB: Name your <div>s "$group$page", where $group identifies a page location and
  // $page identifies a specific thing to display there.

  // alert("switchPages(" + group + ", " + page + ") entered. visiblePage [" + visiblePages[group] + "]");    
  var newVisiblePage = group + page;
  if ( visiblePages[group] ) {
    // Hide the current div layer
    var element = null;
    if ( document.getElementById ) {
      element = document.getElementById(visiblePages[group]);
    }

    if ( element ) {
      element.style.visibility = "hidden";
      element.style.display = "none";
    }
  }

  // Show the requested div layer
  var windowToShow = null;
  if ( document.getElementById ) {
    windowToShow = document.getElementById(newVisiblePage);

    if ( windowToShow ) {
      windowToShow.style.visibility = "visible";
      windowToShow.style.display = "block";

    // Set the div layer to hide next time
    visiblePages[group] = newVisiblePage;
    }
  }
} // end switchPages
  
